#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>

#include "vect.h"

int DEBUG = 0;

typedef int sat;

const sat SAT = 0;
const sat UNSAT = 1;
const sat UNKNOWN = 2;

typedef int litteral;

struct cnf {
    litteral **clauses;
    int nb_clauses;
    int nb_variables;
};

typedef struct cnf cnf;

// Utility function, you shouldn't have to call it directly.
int* read_clause(FILE *fp){
    vect c = vect_make();
    while (true) {
        int litt;
        if (fscanf(fp, "%d", &litt) != 1) assert(false);
        if (litt == 0) break;
        vect_push(c, litt);
    }

    int *clause = malloc((1 + vect_length(c)) * sizeof(int));
    clause[0] = vect_length(c);
    for (int i = 1; i <= vect_length(c); i++) {
        clause[i] = vect_get(c, i - 1);
    }

    vect_free(c);
    return clause;
}


// Input : a file pointer fp. The corresponding file should be open
// for reading, and contain a cnf formula in DIMACS format.
//
// Output : a cnf* pointing to a representation of the formula.
//
// Note : the function does not close the file.
cnf *read_cnf(FILE *fp){
    cnf *f = malloc(sizeof(cnf));

    // skip initial comments
    char header = fgetc(fp);
    while (header == 'c') {
        while (fgetc(fp) != '\n') {}
        header = fgetc(fp);
    }

    // line should be "p x y"
    assert(header == 'p');

    fscanf(fp, " cnf %d %d", &f->nb_variables, &f->nb_clauses);
    f->clauses = malloc(f->nb_clauses * sizeof(int*));

    for (int i = 0; i < f->nb_clauses; i++) {
        f->clauses[i] = read_clause(fp);
    }

    return f;
}


// Frees all the memory associated with f, including
// the struct itself. Assumes f is heap-allocated, which will
// be the case if it was obtained through a call to read_cnf or
// cnf_copy.
void cnf_free(cnf *f){
    for (int i = 0; i < f->nb_clauses; i++) {
        free(f->clauses[i]);
    }
    free(f->clauses);
    free(f);
}

// Returns a deep copy of the cnf pointed to by f.
// Only the active parts of the formula are copied
// (eg not the previously deleted clauses and litterals).
cnf *cnf_copy(cnf *f){
    cnf *g = malloc(sizeof(cnf));
    g->nb_variables = f->nb_variables;
    g->nb_clauses = f->nb_clauses;
    g->clauses = malloc(g->nb_clauses * sizeof(litteral*));
    for (int i = 0; i < g->nb_clauses; i++) {
        int *clause = f->clauses[i];
        g->clauses[i] = malloc((clause[0] + 1) * sizeof(litteral));
        for (int j = 0; j <= clause[0]; j++) {
            g->clauses[i][j] = clause[j];
        }
    }
    return g;
}

// Prints a formula on stderr
void print_cnf(cnf *f){
    fprintf(stderr, "nb_clauses = %d\n", f->nb_clauses);
    fprintf(stderr, "nb_variables = %d\n", f->nb_variables);
    for (int i = 0; i < f->nb_clauses; i++){
        fprintf(stderr, "Size %d :", f->clauses[i][0]);
        for (int j = 1; j <= f->clauses[i][0]; j++) {
            fprintf(stderr, " %d", f->clauses[i][j]);
        }
        fprintf(stderr, "\n");
    }
}


sat remove_clause(cnf *f, int clause_index);

sat remove_litteral(litteral clause[], int lit_index);

int get_litteral_occurrence(litteral clause[], litteral l);

sat assert_litteral(cnf *f, litteral valuation[], litteral l);

litteral get_unit_litteral(cnf *f);

struct litt_occurrences {
    int pos;
    int neg;
};

typedef struct litt_occurrences litt_occurrences;

void count_occurrences(cnf *f, litt_occurrences occs[]);

litteral get_pure_litteral(cnf *f, litt_occurrences *occs);

litteral get_decision_litteral(cnf *f, litt_occurrences *occs);

void print_valuation(FILE *fp, int *valuation, int len){
    for (int i = 1; i < len; i++) {
        fprintf(fp, "%d ", valuation[i]);
    }
    fprintf(fp, "0\n");
}

sat unit_propagation(cnf *f, int *valuation);


int *dpll(cnf *f, bool *satisfiable);

bool check_solution(cnf *f, int *valuation){
    for (int i = 0; i < f->nb_clauses; i++){
        int *clause = f->clauses[i];
        bool ok = false;
        for (int j = 1; j <= clause[0] && !ok; j++) {
            litteral x = clause[j];
            if (valuation[abs(x)] == x) ok = true;
        }
        if (!ok) return false;
    }
    return true;
}



int main(int argc, char* argv[]){
    DEBUG = 0;

    return 0;
}
