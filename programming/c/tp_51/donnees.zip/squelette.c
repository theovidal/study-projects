#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <assert.h>
#include <string.h>

#include "bitpacking.h"
#include "stack.h"

typedef uint32_t cw_t;
typedef uint8_t byte_t;

#define CW_MAX_WIDTH 16
#define DICTFULL (1u << CW_MAX_WIDTH)

const cw_t NO_ENTRY = DICTFULL;
const cw_t NULL_CW = DICTFULL;
const cw_t FIRST_CW = 0x100;
const int CW_MIN_WIDTH = 9;

int VERBOSITY = 0;

struct dict_entry_t {
    cw_t pointer;
    uint8_t byte;
};

typedef struct dict_entry_t dict_entry_t;

struct dict_t {
    cw_t next_available_cw;
    int cw_width;
    dict_entry_t data[DICTFULL];
};

struct dict_t dict;

cw_t inverse_table[DICTFULL][256];



int main(int argc, char* argv[]){

   return EXIT_SUCCESS;
}
