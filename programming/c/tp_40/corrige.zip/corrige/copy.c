#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>

int main(int argc, char* argv[]) {
  bool corrupted = false;
  int i = 1;
  if (argc > 1 && strcmp(argv[1], "--corrupted") == 0) {
    corrupted = true;
    i++;
  }
  if ((corrupted && argc != 4) || (!corrupted && argc != 3)) {
    fprintf(stderr, "Usage: copy [--corrupted] file1 file2\n");
    return EXIT_FAILURE;
  }
  FILE* src = fopen(argv[i], "r");
  if (src == NULL) {
    fprintf(stderr, "Error: cannot open %s (read)\n", argv[i]);
    return EXIT_FAILURE;
  }
  FILE* dst = fopen(argv[i + 1], "w");
  if (dst == NULL) {
    fprintf(stderr, "Error: cannot open %s (write)\n", argv[i + 1]);
    return EXIT_FAILURE;
  }

  char c = '\0';
  while (fscanf(src, "%c", &c) == 1) {
    if (corrupted) {
      if (c == 'a') {c = 'e';}
      else if (c == 'e') {c = 'a';}
    }
    fprintf(dst, "%c", c);
  }
  fclose(src);
  fclose(dst);
}
