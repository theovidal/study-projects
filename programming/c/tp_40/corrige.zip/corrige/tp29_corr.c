#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

int main(void) {

  // Question 1
  FILE* f0 = fopen("mon_fichier.txt", "w");
  fclose(f0);

  // Question 2
  FILE* f1 = fopen("mon_fichier.txt", "w");
  fprintf(f1, "Première ligne\nDeuxième ligne\n");
  fclose(f1);

  // Question 3
  FILE* f2 = fopen("mon_fichier.txt", "r");
  while (true) {
    char c = '\0';
    if (fscanf(f2, "%c", &c) != 1) break;
    printf("%c", c);
  }
  fclose(f2);

  // Question 4
  FILE* f3 = fopen("mon_fichier.txt", "a");
  fprintf(f3, "Dernière ligne\n");
  fclose(f3);

  // Question 5
  FILE* f4 = fopen("plot.txt", "w");
  for (int i = 0; i < 10000; i++) {
    fprintf(f4, "%d %d\n", i, i * i);
  }
  fclose(f4);

}
