#include <stdlib.h>
#include <stdio.h>

int main(void) {

  FILE* f = fopen("data/pi/pi.txt", "r");
  if (f == NULL) {
    fprintf(stderr, "Eprreur : impossible d'ouvrir le fichier ./data/pi/pi.txt\n");
    return EXIT_FAILURE;
  }

  int nb_decimales = 0;
  // Initialise occurrences à {0, 0, ..., 0}
  int occurrences[10] = {0};

  char c = '\0';
  int nb = fscanf(f, "%c", &c);
  while (nb != EOF) {
    occurrences[c - '0']++;
    nb_decimales++;
    nb = fscanf(f, "%c", &c);
  }

  for (int i = 0; i < 10; i++) {
    printf("%d : %f\n", i, (double)occurrences[i] / (double)nb_decimales);
  }

  fclose(f);

  return EXIT_SUCCESS;

}
