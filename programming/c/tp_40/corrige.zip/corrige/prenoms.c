#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <assert.h>

#define FICHIER_PRENOM "data/prenoms/prenoms.txt"

void affiche_histogramme_lettre_debut(int max_longueur_prenom) {

  FILE* f_prenoms = fopen(FICHIER_PRENOM, "r");
  if (f_prenoms == NULL) {
    fprintf(stderr, "Impossible d'ouvir %s\n", FICHIER_PRENOM);
    exit(EXIT_FAILURE);
  }

  int nb[256] = {0};

  char* ligne = malloc(max_longueur_prenom + 1);
  while (true) {
    // Remarque : on peut avoir de gros problèmes si la mémoire
    // allouée pour la ligne n'est pas assez grande. Ici, on s'en est
    // assuré (sauf si quelque de mal intentionné change le fichier
    // entre temps...). En pratique, il vaudrait mieux utiliser
    // `fgets` qui est sûr mais qui n'est pas au programme.
    if (fscanf(f_prenoms, "%s", ligne) == EOF) break;
    assert(strlen(ligne) > 0);
    nb[(int)ligne[0]]++;
  }
  free(ligne);

  printf("- Nombre de prénoms par première lettre : \n");
  for (int i = 0; i < 256; i++) {
    if (nb[i] > 0) {
      printf("\t%c : %d\n", i, nb[i]);
    }
  }

  printf("\n");

  fclose(f_prenoms);
}

void affiche_prenoms_plus_longs(int max_longueur_prenom) {

  FILE* f_prenoms = fopen(FICHIER_PRENOM, "r");

  printf("- Prénoms les plus longs :\n");

  char* ligne = malloc(max_longueur_prenom + 1);
  while (fscanf(f_prenoms, "%s", ligne) != EOF) {
    if ((int)strlen(ligne) == max_longueur_prenom) {
      printf("\t%s\n", ligne);
    }
  }
  free(ligne);

  printf("\n");

  fclose(f_prenoms);
}

void affiche_prenoms_plus_courts(int max_longueur_prenom) {

  FILE* f_prenoms = fopen(FICHIER_PRENOM, "r");

  printf("- Prénoms les plus cours :\n");

  char* ligne = malloc(max_longueur_prenom + 1);
  while (fscanf(f_prenoms, "%s", ligne) != EOF) {
    // Triche, il faudrait faire une première passe pour trouver la
    // longueur minimale, je sais que c'est `1` mais ce n'est pas
    // nécessairement le cas pour toute liste de prénoms.
    if ((int)strlen(ligne) == 1) {
      printf("\t%s\n", ligne);
    }
  }
  free(ligne);

  printf("\n");

  fclose(f_prenoms);
}

int compare_char(const void* c1, const void* c2) {
  return *(char*)c1 - *(char*)c2;
}

bool anagramme(char* str, char* temoin) {
  int n = strlen(str);
  char* lettres_triees = malloc(n + 1);
  strcpy(lettres_triees, str);
  // On pourrait implémenter un tri par dénombrement linéaire plutôt
  // que d'utiliser `qsort`
  qsort(lettres_triees, n, 1, compare_char);
  bool res = strcmp(lettres_triees, temoin) == 0;
  free(lettres_triees);
  return res;
}

// Vérifie si un prénom a été donné et trouve tous ses prénoms
// anagrammes, ce qui répond à la question 14
void affiche_existe_et_anagrammes(char* prenom, int max_longueur_prenom) {

  int n = strlen(prenom);
  char* prenom_trie = malloc(n + 1);
  strcpy(prenom_trie, prenom);
  qsort(prenom_trie, n, 1, compare_char);

  FILE* f_prenoms = fopen(FICHIER_PRENOM, "r");

  printf("- Anagrammes de %s :\n", prenom);

  bool trouve = false;
  char* ligne = malloc(max_longueur_prenom + 1);
  while (fscanf(f_prenoms, "%s", ligne) != EOF) {
    if (anagramme(ligne, prenom_trie)) {
      if (strcmp(prenom, ligne) == 0) {
        trouve = true;
      }
      printf("\t%s\n", ligne);
    }
  }
  free(ligne);

  free(prenom_trie);

  printf("\n- Le prénom %s %s été trouvé.\n\n", prenom, trouve ? "a" : "n'a pas");

  fclose(f_prenoms);
}

void affiche_proportion_prenoms_contenant_la_lettre(char c, int max_longueur_prenom) {

  FILE* f_prenoms = fopen(FICHIER_PRENOM, "r");

  int nb_avec = 0;
  int nb_tout = 0;
  char* ligne = malloc(max_longueur_prenom + 1);
  while (fscanf(f_prenoms, "%s", ligne) != EOF) {
    if (strchr(ligne, c) != NULL) {
      nb_avec += 1;
    }
    nb_tout += 1;
  }
  free(ligne);

  printf("- Il y a %.2f%% des prénoms qui contiennent la lettre %c :\n\n", nb_avec * 100. / nb_tout, c);

  fclose(f_prenoms);
}

bool est_palindrome(char* s) {
  int n = strlen(s);
  for (int i = 0; i < n / 2; i++) {
    if (s[i] != s[n - 1 - i]) {
      return false;
    }
  }
  return true;
}

void affiche_prenoms_palindromiques(int max_longueur_prenom) {

  FILE* f_prenoms = fopen(FICHIER_PRENOM, "r");

  printf("- Prénoms palindromiques :\n");

  char* ligne = malloc(max_longueur_prenom + 1);
  while (fscanf(f_prenoms, "%s", ligne) != EOF) {
    if (est_palindrome(ligne)) {
      printf("\t%s\n", ligne);
    }
  }
  free(ligne);

  fclose(f_prenoms);
}

int main(void) {

  FILE* f_prenoms = fopen(FICHIER_PRENOM, "r");
  if (f_prenoms == NULL) {
    fprintf(stderr, "Impossible d'ouvir %s\n", FICHIER_PRENOM);
    return EXIT_FAILURE;
  }

  int nb_prenoms = 0;
  int longueur_prenom = 0;
  int max_longueur_prenom = 0;
  while (true) {
    char c = '\0';
    if (fscanf(f_prenoms, "%c", &c) != 1) break;
    if (c == '\n') {
      nb_prenoms++;
      if (longueur_prenom > max_longueur_prenom) {
        max_longueur_prenom = longueur_prenom;
      }
      longueur_prenom = 0;
    } else {
      longueur_prenom++;
    }
  }

  fclose(f_prenoms);

  printf("Il y a %d prénoms.\n\n", nb_prenoms);
  printf("Le prénom le plus long est de longueur : %d.\n\n", max_longueur_prenom);

  affiche_histogramme_lettre_debut(max_longueur_prenom);
  affiche_prenoms_plus_longs(max_longueur_prenom);
  affiche_prenoms_plus_courts(max_longueur_prenom);
  affiche_existe_et_anagrammes("maelie", max_longueur_prenom);
  affiche_proportion_prenoms_contenant_la_lettre('e', max_longueur_prenom);
  affiche_prenoms_palindromiques(max_longueur_prenom);

}
