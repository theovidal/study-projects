#include <stdlib.h>
#include <stdio.h>

int main(int argc, char* argv[]) {

  FILE* f = fopen("data/pi/pi.txt", "r");
  if (f == NULL) {
    fprintf(stderr, "Eprreur : impossible d'ouvrir le fichier ./data/pi/pi.txt\n");
    return EXIT_FAILURE;
  }

  if (argc < 2) {
    fprintf(stderr, "Erreur : il manque un argument n > 0\n");
    return EXIT_FAILURE;
  }
  int n = atoi(argv[1]);
  if (n <= 0) {
    fprintf(stderr, "Erreur : n <= 0\n");
    return EXIT_FAILURE;
  }

  char c = '\0';
  for (int i = 1; i <= n; i++) {
    int nb = fscanf(f, "%c", &c);
    if (nb < 0) {
      fprintf(stderr, "Erreur : impossible de lire la décimale %i\n", i);
      return EXIT_FAILURE;
    }
  }

  printf("%c\n", c);

  fclose(f);

  return EXIT_SUCCESS;

}
