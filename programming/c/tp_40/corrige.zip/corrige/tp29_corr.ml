
(*::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*)
(* Nicolas Pécheux <info.cpge@cpge.info>                            *)
(* Thursday, 17 March 2022                                          *)
(* http://cpge.info                                                 *)
(*::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*)

(** Question 1 **)
let f = open_out "mon_fichier.txt"
let () = close_out f

(** Question 2 **)
let f = open_out "mon_fichier.txt"
let () = output_string f "Première ligne\n"
let () = output_string f "Deuxième ligne\n"
let () = close_out f

(** Question 3 **)
let f = open_in "mon_fichier.txt"
let () =
  try
    while true do
      print_endline (input_line f)
    done
  with End_of_file -> ()
let () = close_in f

(** Question 5 **)
let f = open_out "plot.txt"
let () =
  for i = 0 to 9999 do
    output_string f (string_of_int i ^ " " ^ string_of_int (i * i) ^ "\n")
  done
let () = close_out f
