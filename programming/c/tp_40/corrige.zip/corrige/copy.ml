
(*::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*)
(* Nicolas Pécheux <info.cpge@cpge.info>                            *)
(* Thursday, 17 March 2022                                          *)
(* http://cpge.info                                                 *)
(*::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*)

let () =
  let n = Array.length Sys.argv in
  let corrompu = n > 1 && Sys.argv.(1) = "--corrupted" in
  if (corrompu && n <> 4 || (not corrompu) && n <> 3) then begin
    Printf.fprintf stderr "Usage: copy [--corrupted] file1 file2\n";
    exit 1
  end;
  let src = open_in Sys.argv.(if corrompu then 2 else 1) in
  let dst = open_out Sys.argv.(if corrompu then 3 else 2) in
  try
    if not corrompu then
      while true do
        output_char dst (input_char src)
      done
    else
      while true do
        let c = input_char src in
        let c = if c = 'a' then 'e' else if c = 'e' then 'a' else c in
        output_char dst c
      done
  with End_of_file ->
    close_in src;
    close_out dst
