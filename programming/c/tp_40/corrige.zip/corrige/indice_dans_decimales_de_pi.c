#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>

// Lecture de `n` caractères du flot `flot` dans la chaîne de
// caractères `dest`, supposée de taille au moins `n + 1`. On
// repositionne le curseur au début du flot, là où l'on en était avant
// l'appel à la fonction. Renvoie le nombre de caractères effectivment
// lus.
int lecture(int n, char* dest, FILE* flot) {
  int nb_lu = 0;
  int position = ftell(flot);
  char c = '\0';
  while (nb_lu < n) {
    int nb = fscanf(flot, "%c", &c);
    if (nb != 1) {break;}
    dest[nb_lu] = c;
    nb_lu++;
  }
  dest[nb_lu] = '\0';
  fseek(flot, position, SEEK_SET);
  return nb_lu;
}

int main(int argc, char* argv[]) {

  FILE* f = fopen("data/pi/pi.txt", "r");
  if (f == NULL) {
    fprintf(stderr, "Erreur : impossible d'ouvrir le fichier ./data/pi/pi.txt\n");
    return EXIT_FAILURE;
  }

  if (argc < 2) {
    fprintf(stderr, "Erreur : il manque un argument n positif\n");
    return EXIT_FAILURE;
  }

  char* nombre = argv[1];
  int n = strlen(nombre);

  char* nombre_test = malloc(n + 1);
  int pos = 1;

  while (true) {
    int nb_lu = lecture(n, nombre_test, f);
    if (nb_lu != n) {
      // On est arrivé à la fin du fichier sans trouver
      printf("-1\n");
      break;
    } else if (strcmp(nombre, nombre_test) == 0) {
      // On a trouvé
      printf("%d\n", pos);
      break;
    }
    pos++;
    fseek(f, 1, SEEK_CUR);
  }

  free(nombre_test);
  fclose(f);

}
