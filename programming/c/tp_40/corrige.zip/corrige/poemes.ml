
(*::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*)
(* Nicolas Pécheux <info.cpge@cpge.info>                            *)
(* Sunday, 20 March 2022                                            *)
(* http://cpge.info                                                 *)
(*::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*)

let data_dir = "data/queneau"

let () = Random.self_init ()

(* Affiche la première ligne du fichier {r}{i}v{j} avec r \in {q, t}. *)
let affiche_premiere_ligne r i j =
  let fo = open_in (data_dir ^ "/" ^ r ^ string_of_int i ^ "v" ^ string_of_int j ^ ".txt") in
  print_endline (input_line fo);
  close_in fo

(* Affiche le premier des 10^{14} poèmes. *)
let premier_poeme () =
  for i = 1 to 2 do
    for j = 1 to 4 do
      affiche_premiere_ligne "q" i j;
    done;
    print_newline ()
  done;
  for j = 1 to 3 do
    affiche_premiere_ligne "t" 1 j;
  done;
  print_newline ()
  for j = 1 to 3 do
    affiche_premiere_ligne "t" 2 j;
  done

(* let () = premier_poeme () *)

(* Affiche dans `out` une des 10 lignes du fichier {r}{i}v{j} avec r
   in {q, t}, choisie uniformément. *)
let affiche_ligne_aleatoire r i j out =
  let fo = open_in (data_dir ^ "/" ^ r ^ string_of_int i ^ "v" ^ string_of_int j ^ ".txt") in
  let r = Random.int 10 in
  for i = 0 to r - 1 do
    ignore (input_line fo)
  done;
  output_string out (input_line fo ^ "\n");
  close_in fo

(* Affiche dans `out` au hasard un des 10^{14} poèmes. *)
let compose_poeme_to out () =
  for i = 1 to 2 do
    for j = 1 to 4 do
      affiche_ligne_aleatoire "q" i j out
    done;
    output_string out "\n"
  done;
  for j = 1 to 3 do
    affiche_ligne_aleatoire "q" 1 j out
  done;
  output_string out "\n";
  for j = 1 to 3 do
    affiche_ligne_aleatoire "q" 2 j out
  done

let compose_poeme = compose_poeme_to stdout

(* let () = compose_poeme () *)

let sauvegarde_poemes () =
  for i = 0 to 99 do
    let num = (if i < 10 then "0" else "") ^ string_of_int i in
    let fo = open_out ("poeme" ^ num ^ ".txt") in
    compose_poeme_to fo ();
    close_out fo
  done

(* let () = sauvegarde_poemes () *)
